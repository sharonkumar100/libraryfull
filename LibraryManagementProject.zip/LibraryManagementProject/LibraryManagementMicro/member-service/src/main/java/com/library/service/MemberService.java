package com.library.service;

import com.library.entity.Member;
import com.library.exception.MemberException;
import com.library.repository.MemberRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;
import java.util.Optional;

@Service
@Slf4j
public class MemberService {
	@Autowired
	private MemberRepository memberRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	private final String FOLDER_PATH="C:/Angular/librarymanagement/public/assets/members/";
	private final String ANGULAR_PATH="/assets/members/";

	public String registerMember(Member member) {
		// Check if the email already exists in the database
		List<Member> existingMembers = memberRepository.findByEmail(member.getEmail());
		if (!existingMembers.isEmpty()) {
			throw new MemberException("Email already present");
		}
		else {
			// Save the new member if email is unique
			String hashedpassword = passwordEncoder.encode(member.getPassword());
			member.setPassword(hashedpassword);
			memberRepository.save(member);
			return "Member saved successfully";
		}
	}



	public String uploadImageToFileSystem(MultipartFile file) throws IOException {
		String filepath=FOLDER_PATH+file.getOriginalFilename();
//		FileData fileData=fileDataRepository.save(FileData.builder()
//				.name(file.getOriginalFilename())
//				.type(file.getContentType())
//				.filePath(filepath).build() );
		file.transferTo(new File(filepath));
//		if(fileData!=null){
//			return "file uploaded successfully: "+filepath;
//		}
//		return null;

		return ANGULAR_PATH+file.getOriginalFilename();
	}

	public byte[] downloadImageFileSystem(String fileName) throws IOException{
		Optional<Member> fileData=memberRepository.findByProfileimg(fileName);
//		String filePath=fileData.get().getFilePath();
		String filePath=fileData.get().getProfileimg();
//        byte[] images= ImageUtils.decompressImage(dbImageData.get().getImageData());
		byte[] images= Files.readAllBytes(new File(filePath).toPath());
		return images;

	}


	public List<Member> getMemberByEmail(String email) {
		List<Member> list =  memberRepository.findByEmail(email);  // Returns a List<Member> now
		if(list.isEmpty()){
			throw new MemberException("No Email Found");
		}else{
			return list;
		}
	}

	public void updateMembershipStatus(int memberID, String status) {
		Member member = memberRepository.findById(memberID)
				.orElseThrow(() -> new MemberException("Member not found"));
		member.setMembershipStatus(status);
		memberRepository.save(member);
	}

	public Member updateMember(int id, Member member) {
		Optional<Member> optionalMember = memberRepository.findById(id);
		if (optionalMember.isPresent()) {
			Member member1 = optionalMember.get();
			member1.setEmail(member.getEmail());
			member1.setAddress(member.getAddress());
			member1.setName(member.getName());
			member1.setMembershipStatus(member.getMembershipStatus());
			member1.setPhone(member.getPhone());
			memberRepository.save(member);
			return member1;
		} else {
			return null;
		}
	}

	public List<Member> getAllMembers() {
		return memberRepository.findAll();
	}

	public Member getMember(int id) {
		Optional<Member> member = memberRepository.findById(id);
		if(member.isEmpty()){
			throw new MemberException("No member present with that id");
		}else{
			return member.get();
		}
	}

	public Member deleteMember(int id) {
		Optional<Member> member = memberRepository.findById(id);
		if(member.isEmpty()){
			throw new MemberException("No Member Found with that Id");
		}
		memberRepository.deleteById(id);
		return member.get();
	}

	public ResponseEntity<Member> loginUser(String email, String password) {
		List<Member> member=memberRepository.findByEmail(email);
		if(member==null){
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		boolean matches = passwordEncoder.matches(password,member.get(0).getPassword());
		if(matches){
			Member memberStatus = new Member();
			memberStatus.setEmail(email);
			List<Member> list = memberRepository.findByEmail(email);
			memberStatus.setRole(list.get(0).getRole());
			memberStatus.setMemberID(list.get(0).getMemberID());
			return new ResponseEntity<>(memberStatus,HttpStatus.CREATED);
		}else{
			throw new MemberException("password incorrect");
		}

	}
}
