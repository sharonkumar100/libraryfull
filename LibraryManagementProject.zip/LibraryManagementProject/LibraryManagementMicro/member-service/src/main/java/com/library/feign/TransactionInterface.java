package com.library.feign;

import com.library.entity.BorrowingTransaction;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@FeignClient(value = "BORROWINGTRANSACTION-SERVICE")
public interface TransactionInterface {

    @DeleteMapping("/transactions/member/{id}")
    public ResponseEntity<List<BorrowingTransaction>> deleteTransactionByMemberId(@PathVariable("id")int id);

    @DeleteMapping("/transactions/book/{id}")
    public ResponseEntity<List<BorrowingTransaction>> deleteTransactionByBookId(@PathVariable("id")int id);
}
