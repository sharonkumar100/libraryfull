package com.library.controller;

import com.library.entity.BorrowingTransaction;
import com.library.entity.Member;
import com.library.exception.MemberException;
import com.library.feign.TransactionInterface;
import com.library.service.MemberService;
import org.apache.coyote.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/members")
@CrossOrigin(origins = "http://localhost:4200")
public class MemberController {
    @Autowired
    private MemberService memberService;

    @Autowired
    TransactionInterface transactionInterface;

//    @PostMapping(value = "/register",consumes = {"multipart/form-data"})
//    public ResponseEntity<String> registerMember(@RequestPart("member") Member member, @RequestPart(value = "file",required = false
//    )MultipartFile image) {
//        System.out.println("It is coming till here ra sharon");
//        try {
//            if (image != null && !image.isEmpty()) {
//                member.setProfileImage(image.getBytes());
//            }
//            String registeredMember = memberService.registerMember(member);
//            return new ResponseEntity<>(registeredMember, HttpStatus.CREATED);
//        } catch (MemberException e) {
//            return ResponseEntity.badRequest().body(e.getMessage());
//        } catch (IOException e) {
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error uploading image");
//        }
//    }

    @PostMapping("/register")
    public ResponseEntity<String> registerMember(@RequestBody Member member) {
        try {
            System.out.println("calling the register method try");
            String registeredMember = memberService.registerMember(member);
//            return new ResponseEntity<>(registeredMember, HttpStatus.CREATED);
            return ResponseEntity.status(HttpStatus.OK).body(registeredMember);
        } catch (MemberException e) {

            System.out.println("calling the register method catch");
//            return ResponseEntity.badRequest().body(e.getMessage());
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/fileSystem")
    public ResponseEntity<?> uploadImageToFIleSystem(@RequestParam("image") MultipartFile file) throws IOException {
        System.out.println("coming here atleast");
        String uploadImage = memberService.uploadImageToFileSystem(file);
//        return ResponseEntity.status(HttpStatus.OK)
//                .body(uploadImage);
        return new ResponseEntity<>(uploadImage,HttpStatus.OK);
    }

    @GetMapping("/fileSystem/{fileName}")
    public ResponseEntity<?> downloadImageFromFileSystem(@PathVariable String fileName) throws IOException {
        byte[] imageData=memberService.downloadImageFileSystem(fileName);
        return ResponseEntity.status(HttpStatus.OK)
                .contentType(MediaType.valueOf("image/png"))
                .body(imageData);

    }

    @GetMapping("/login")
    public ResponseEntity<Member> loginUser(@RequestParam("email") String email,@RequestParam("password") String password){
        return memberService.loginUser(email,password);
    }




    @GetMapping("/email/{email}")
    public ResponseEntity<Member> getMemberByEmail(@PathVariable String email) {
        try {
            List<Member> members = memberService.getMemberByEmail(email);
            return new ResponseEntity(members,HttpStatus.CREATED);
        }
        catch (Exception e){
            return new ResponseEntity(e.getMessage(),HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping
    public ResponseEntity<List<Member>> getAllMembers() {
        return new ResponseEntity<>(memberService.getAllMembers(), HttpStatus.CREATED);
    }

    @GetMapping("/id/{id}")
    public ResponseEntity<Member> getMember(@PathVariable("id") int id) {
        System.out.println(" logger ...."+id);
        try {
            return new ResponseEntity<>(memberService.getMember(id), HttpStatus.CREATED);
        }catch (Exception e){
            return new ResponseEntity(e.getMessage(),HttpStatus.NOT_FOUND);
        }

    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Member> deleteMember(@PathVariable("id") int id) {

        try{
            try {
                List<BorrowingTransaction> list = transactionInterface.deleteTransactionByMemberId(id).getBody();
            }catch (Exception e){
                System.out.println(e.getMessage());
            }
            Member memberData = memberService.deleteMember(id);
            return new ResponseEntity<>(memberData, HttpStatus.CREATED);
        } catch (Exception e){
            return new ResponseEntity(e.getMessage(),HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Member> updateMember(@PathVariable("id") int id, @RequestBody Member member) {
        Member memberData = memberService.updateMember(id, member);
        if (memberData != null) {
            return new ResponseEntity<>(memberData, HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
