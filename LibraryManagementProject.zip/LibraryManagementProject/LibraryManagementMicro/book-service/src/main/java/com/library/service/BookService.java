package com.library.service;

import com.library.entity.Book;
import com.library.exception.BookException;
import com.library.repository.BookRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;
import java.util.Optional;

@Service
@Slf4j
public class BookService {
    @Autowired
    private BookRepository bookRepository;


    private final String FOLDER_PATH="C:/Angular/librarymanagement/public/assets/books/";
    private final String ANGULAR_PATH="/assets/books/";

    public Book addBook(Book book) {
        log.info("Book is saved successfully "+book);
        return bookRepository.save(book);
    }

    public String uploadImageToFileSystem(MultipartFile file) throws IOException {
        String filepath=FOLDER_PATH+file.getOriginalFilename();
//		FileData fileData=fileDataRepository.save(FileData.builder()
//				.name(file.getOriginalFilename())
//				.type(file.getContentType())
//				.filePath(filepath).build() );
        file.transferTo(new File(filepath));
//		if(fileData!=null){
//			return "file uploaded successfully: "+filepath;
//		}
//		return null;

        return ANGULAR_PATH+file.getOriginalFilename();
    }

    public byte[] downloadImageFileSystem(String fileName) throws IOException{
        Optional<Book> fileData=bookRepository.findByBookurl(fileName);
//		String filePath=fileData.get().getFilePath();
        String filePath=fileData.get().getBookurl();
//        byte[] images= ImageUtils.decompressImage(dbImageData.get().getImageData());
        byte[] images= Files.readAllBytes(new File(filePath).toPath());
        return images;

    }

    public List<Book> searchBooksTitle(String title) {
        return bookRepository.findByTitleContaining(title);
    }

    public List<Book> searchBooksAuthor(String author) {
        return bookRepository.findByAuthorContaining(author);
    }

    public List<Book> searchBooksGenre(String genre) {
        return bookRepository.findByGenreContaining(genre);
    }

    public void updateAvailableCopies(int bookID, int change) {
        Book book = bookRepository.findById(bookID).orElseThrow(() -> new BookException("Book not found"));
        book.setAvailableCopies(change);
        bookRepository.save(book);
    }

    public Book updateBook(int id, Book bookDetails) {
        Book book = bookRepository.findById(id).orElseThrow(() -> new BookException("Book not found"));
        book.setTitle(bookDetails.getTitle());
        book.setAuthor(bookDetails.getAuthor());
        book.setGenre(bookDetails.getGenre());
        book.setIsbn(bookDetails.getIsbn());
        book.setYearPublished(bookDetails.getYearPublished());
        book.setAvailableCopies(bookDetails.getAvailableCopies());
        return bookRepository.save(book);
    }

    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    public void deleteBook(int id) {
        if (!bookRepository.existsById(id)) {
            throw new BookException("Book not found");
        }
        bookRepository.deleteById(id);
    }

    public Book getBook(int id) {
        return bookRepository.findById(id).orElseThrow(() -> new BookException("No book is found with this ID"));
    }
}