package com.library.controller;

import com.library.entity.Book;
import com.library.entity.BorrowingTransaction;
import com.library.exception.BookException;
import com.library.feign.TransactionInterface;
import com.library.service.BookService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/books")
@CrossOrigin(value = "http://localhost:4200")
public class BookController {
    @Autowired
    private BookService bookService;

    @Autowired
    private TransactionInterface transactionInterface;

    @PostMapping("/addbook")
    public ResponseEntity<Book> addBook(@RequestBody Book book) {
        try {
            Book savedBook = bookService.addBook(book);
            System.out.println("Coming here");
            return new ResponseEntity<>(savedBook,HttpStatus.CREATED);
        } catch (BookException e) {
            return ResponseEntity.badRequest().body(null);
        }
    }

    @PostMapping("/fileSystem")
    public ResponseEntity<?> uploadImageToFIleSystem(@RequestParam("image") MultipartFile file) throws IOException {
        System.out.println("coming here atleast");
        String uploadImage = bookService.uploadImageToFileSystem(file);
//        return ResponseEntity.status(HttpStatus.OK)
//                .body(uploadImage);
        return new ResponseEntity<>(uploadImage,HttpStatus.OK);
    }

    @GetMapping("/fileSystem/{fileName}")
    public ResponseEntity<?> downloadImageFromFileSystem(@PathVariable String fileName) throws IOException {
        byte[] imageData=bookService.downloadImageFileSystem(fileName);
        return ResponseEntity.status(HttpStatus.OK)
                .contentType(MediaType.valueOf("image/png"))
                .body(imageData);

    }

    @GetMapping("/title/{title}")
    public ResponseEntity<List<Book>> searchBooksByTitle(@PathVariable String title) {
        try {
            List<Book> books = bookService.searchBooksTitle(title);
            return ResponseEntity.ok(books);
        } catch (BookException e) {
            return ResponseEntity.badRequest().body(null);
        }
    }

    @GetMapping("/author/{author}")
    public ResponseEntity<List<Book>> searchBooksByAuthor(@PathVariable String author) {
        try {
            List<Book> books = bookService.searchBooksAuthor(author);
            return ResponseEntity.ok(books);
        } catch (BookException e) {
            return ResponseEntity.badRequest().body(null);
        }
    }

    @GetMapping("/genre/{genre}")
    public ResponseEntity<List<Book>> searchBooksByGenre(@PathVariable String genre) {
        try {
            List<Book> books = bookService.searchBooksGenre(genre);
            return new ResponseEntity<>(books, HttpStatus.CREATED);
        } catch (BookException e) {
            return ResponseEntity.badRequest().body(null);
        }
    }

    @PutMapping("/copies/{bookID}/{change}")
    public ResponseEntity<Void> updateAvailableCopies(@PathVariable int bookID, @PathVariable int change) {
        try {
            bookService.updateAvailableCopies(bookID, change);
            return ResponseEntity.ok().build();
        } catch (BookException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Book> updateBook(@PathVariable int id, @RequestBody Book bookDetails) {
        try {
            Book updatedBook = bookService.updateBook(id, bookDetails);
            return new ResponseEntity<>(updatedBook,HttpStatus.CREATED);
        } catch (BookException e) {
//            return ResponseEntity.badRequest().body(null);
            return new ResponseEntity(e.getMessage(),HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {
        try {
            List<Book> books = bookService.getAllBooks();
            return ResponseEntity.ok(books);
        } catch (BookException e) {
            return ResponseEntity.badRequest().body(null);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable int id) {
        try {
            try {
                List<BorrowingTransaction> list = transactionInterface.deleteTransactionByBookId(id).getBody();
            }catch (Exception e){
                System.out.println(e.getMessage());
            }
            bookService.deleteBook(id);
            return ResponseEntity.ok().build();
//            return new ResponseEntity<>();
        } catch (BookException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Book> getBook(@PathVariable int id) {
        try {
            Book book = bookService.getBook(id);

            return new ResponseEntity<>(book,HttpStatus.CREATED);
        } catch (BookException e) {
            return new ResponseEntity(e.getMessage(),HttpStatus.NOT_FOUND);
        }
    }
}