package com.library.repository;

import com.library.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BookRepository extends JpaRepository<Book, Integer> {

//	Optional<Book> findByTitleAuthorGenre(String title, String author, String genre);
//	
List<Book> findByTitleContaining(String title);
 List<Book> findByAuthorContaining(String author);
 List<Book> findByGenreContaining(String genre);

    Optional<Book> findByBookurl(String fileName);

    //List<Book> findByTitleContainingOrAuthorContainingOrGenreContaining(String title, String author, String genre);
	
}
