package com.library.exception;

public class FineException extends RuntimeException{
    public FineException(String name){
        super(name);
    }
}
