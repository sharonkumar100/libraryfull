package com.library.service;


import com.library.entity.BorrowingTransaction;
import com.library.entity.Fine;
import com.library.entity.Member;
import com.library.exception.FineException;
import com.library.feign.BorrowingTransactionInterface;
import com.library.feign.MemberInterface;
import com.library.repository.FineRepository;
import com.netflix.discovery.converters.Auto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class FineService {
	public static final int days = 28;
	public static final double price = 1.0;
	public static final double max_price = 200;
	@Autowired
	private FineRepository fineRepository;

	@Autowired
	private BorrowingTransactionInterface borrowingTransactionInterface;

	@Autowired
	private MemberInterface memberInterface;

	public List<Fine> getFinesByMemberID(int memberID) {
		generateFines();
		log.info("Fetching fines for member ID: {}", memberID);
		List<Fine> fn = fineRepository.findByMemberId(memberID);
		if(fn.isEmpty()){
			log.warn("No member found with ID: {}", memberID);
			throw new FineException("no member found with that id");
		}else{
			return fn;
		}
	}

	public double getFinesByMember(int memberID) {
		log.info("Calculating total fines for member ID: {}", memberID);
		List<Fine> fines = fineRepository.findByMemberId(memberID);
		double totalAmount = 0;
		if(fines!=null){

			for(Fine fine:fines) {
				if(fine.getStatus().equals("Pending")) {
					totalAmount+=fine.getAmount();
				}
			}

		}
		return totalAmount;
	}


	public List<Fine> generateFines() {
		log.info("Generating fines for all borrowing transactions");
//		List<BorrowingTransaction> bt = borrowingTransactionRepository.findAll();

		ResponseEntity<List<BorrowingTransaction>> bt = borrowingTransactionInterface.getAllTransactions();
		if(bt == null){
			throw new FineException("no history in borrowing transaction");
		}
		List<Fine> list = new ArrayList<>();
		LocalDate currentDate = LocalDate.now();
		for(BorrowingTransaction temp:bt.getBody()) {
			LocalDate borrowingDate = temp.getBorrowDate();
			List<Fine> finesForMember = fineRepository.findByMemberId(temp.getMemberId());
			boolean hasPendingFine = finesForMember.stream()
					.anyMatch(fine -> fine.getStatus().equals("Pending"));
			log.debug("Checking fines for transaction: {}", temp);

			long daysOverdue = ChronoUnit.DAYS.between(borrowingDate, currentDate);
			if(fineRepository.findByTransactionId(temp.getTransactionID())==null) {
				if(daysOverdue<days){

				}else{

				Fine fine = new Fine();
				fine.setMemberId(temp.getMemberId());
//				fine.setMember(temp.getMember());
//				daysOverdue-=days;
				fine.setAmount(daysOverdue*price);
				fine.setStatus("Pending");
				fine.setTransactionDate(currentDate);
				fine.setBookId(temp.getBookId());
//				fine.setBorrowingTransaction(temp);
				fine.setTransactionId(temp.getTransactionID());
				fineRepository.save(fine);
				list.add(fine);

				}
			}
			else if(daysOverdue>=days && fineRepository.findByTransactionId(temp.getTransactionID())!=null && fineRepository.findByTransactionId(temp.getTransactionID()).getStatus().equals("Pending")) {
				log.debug("Updating fine for overdue transaction: {}", temp);
				Fine fine = fineRepository.findByTransactionId(temp.getTransactionID());
//				fine.setMember(temp.getMember());
//				fine.setMemberId(temp.getMemberId());
				daysOverdue-=days;
				fine.setAmount(daysOverdue*price);
				fine.setBookId(temp.getBookId());
				fine.setStatus("Pending");
//				fine.setBorrowingTransaction(temp);
//				fine.setTransactionId(temp.getTransactionID());
				fine.setTransactionDate(currentDate);
				fineRepository.save(fine);
				list.add(fine);
			}
			else if(fineRepository.findByTransactionId(temp.getTransactionID()).getStatus().equals("Pending")){

			}

//			int memberId = temp.getMember().getMemberID();
			int memberId = temp.getMemberId();

			if(getFinesByMember(memberId)>= max_price){
				log.warn("Member {} has exceeded max fine, setting status to inactive", memberId);
//				Member member = temp.getMember();
				Member member = memberInterface.getMember(temp.getMemberId()).getBody();
				member.setMembershipStatus("Inactive");
			}
		}
//		fineRepository.deleteAll();
		log.info("Fine generation completed");
//		fineRepository.saveAll(list);
		return list;
	}

	public List<Fine> getAllFines() {
		generateFines();
		log.info("Fetching all fines");
		List<Fine> fines = fineRepository.findAll();
		return fines;
	}
//
	public String returnBook(int memberID, double amount) {
		log.info("Processing fine payment for member ID: {} with amount: {}", memberID, amount);
		List<Fine> fines = fineRepository.findByMemberId(memberID);
		double totalAmount = 0;
		for(Fine fine:fines) {
			if(fine.getStatus().equals("Pending")) {
				totalAmount+=fine.getAmount();
			}
		}
		if(totalAmount > amount) {
			log.warn("Insufficient amount. Required: {}, Provided: {}", totalAmount, amount);
			throw new FineException("the amount was not sufficient by "+(totalAmount-amount));
		}else {
			for(Fine fine:fines) {
				if(fine.getStatus().equals("Pending")) {
					log.debug("Marking fine as paid for member ID: {}", memberID);
					fine.setStatus("Paid");
					fineRepository.save(fine);
				}
			}
		}
		log.info("Fine successfully paid for member ID: {}", memberID);
		return "successfully Paid";
	}

	public int getDays() {
		return days;
	}

	public Fine getBorrowingTransaction(int id) {
		generateFines();
		return fineRepository.findByTransactionId(id);
	}
	public List<Fine> deleteBookByMemberId(int id) {
		List<Fine> list = fineRepository.deleteByMemberId(id);
		if(list.isEmpty()){
			throw new FineException("No Fines with that memberId");
		}else{
			return list;
		}

	}

	public List<Fine> deleteBookByBookId(int id) {
		List<Fine> list = fineRepository.deleteByBookId(id);
		if(list.isEmpty()){
			throw new FineException("No Fines with that BookId");
		}else{
			return list;
		}
	}
}
