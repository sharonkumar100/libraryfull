package com.library.feign;

import com.library.entity.BorrowingTransaction;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@FeignClient("BORROWINGTRANSACTION-SERVICE")
public interface BorrowingTransactionInterface {
    @PostMapping("/transactions/borrow")
    public ResponseEntity<List<BorrowingTransaction>> borrowBooks(@RequestParam List<Integer> bookIDs, @RequestParam int memberID) ;

    @PostMapping("/transactions/return")
    public ResponseEntity<List<BorrowingTransaction>> returnBooks(@RequestParam List<Integer> bookIDs, @RequestParam int memberID) ;

    @GetMapping("/transactions/member/{memberID}")
    public ResponseEntity<List<BorrowingTransaction>> getTransactionsByMember(@PathVariable("memberID") int memberID) ;

    @GetMapping("/transactions")
    public ResponseEntity<List<BorrowingTransaction>> getAllTransactions() ;

    @GetMapping("/transactions/book/{bookID}")
    public ResponseEntity<List<BorrowingTransaction>> getTransactionsByBook(@PathVariable("bookID") int bookID) ;
}
