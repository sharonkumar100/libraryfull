package com.library.repository;

import com.library.entity.BorrowingTransaction;
import com.library.entity.Fine;
import com.library.entity.Member;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FineRepository extends JpaRepository<Fine, Integer> {
//	List<Fine> findByMember_MemberID(int memberID);

//	List<Fine> findByMember(Member member);
	List<Fine> findByMemberId(int memberId);

//	Fine findByBorrowingTransaction(BorrowingTransaction borrowingTransaction);
	Fine findByTransactionId(int transactionId);

    List<Fine> deleteByMemberId(int memberId);

	List<Fine> deleteByBookId(int bookId);
}
