package com.library.feign;

import com.library.entity.Notification;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;

import java.util.List;

@FeignClient(value = "NOTIFICATION-SERVICE")
//notification-service
public interface NotificationInterface {
    @DeleteMapping("/notifications")
    public List<Notification> deleteAllNotifications() ;
}
