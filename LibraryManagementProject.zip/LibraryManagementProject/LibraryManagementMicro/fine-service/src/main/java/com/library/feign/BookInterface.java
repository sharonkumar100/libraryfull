package com.library.feign;

import com.library.entity.Book;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient("BOOK-SERVICE")
public interface BookInterface {
    @PostMapping("/books/addbook")
    public ResponseEntity<Book> addBook(@RequestBody Book book) ;

    @GetMapping("/books/title/{title}")
    public ResponseEntity<List<Book>> searchBooksByTitle(@PathVariable String title) ;

    @GetMapping("/books/author/{author}")
    public ResponseEntity<List<Book>> searchBooksByAuthor(@PathVariable String author);

    @GetMapping("/books/genre/{genre}")
    public ResponseEntity<List<Book>> searchBooksByGenre(@PathVariable String genre) ;

    @PutMapping("/books/copies/{bookID}/{change}")
    public ResponseEntity<Void> updateAvailableCopies(@PathVariable int bookID, @PathVariable int change);


    @PutMapping("/books/{id}")
    public ResponseEntity<Book> updateBook(@PathVariable int id, @RequestBody Book bookDetails) ;

    @GetMapping("/books")
    public ResponseEntity<List<Book>> getAllBooks() ;

    @DeleteMapping("/books/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable int id) ;

    @GetMapping("/books/{id}")
    public ResponseEntity<Book> getBook(@PathVariable int id) ;
}
