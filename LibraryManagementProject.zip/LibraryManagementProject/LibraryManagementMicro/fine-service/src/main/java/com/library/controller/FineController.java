package com.library.controller;

import com.library.entity.BorrowingTransaction;
import com.library.entity.Fine;
import com.library.feign.NotificationInterface;
import com.library.service.FineService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/fines")
@Slf4j
@CrossOrigin("http://localhost:4200")
public class FineController {
    @Autowired
    private FineService fineService;

    @Autowired
    private NotificationInterface notificationInterface;

    @PostMapping("/generate")
    public ResponseEntity<List<Fine>> generateFines(){
        log.info("Generating fines...");
        List<Fine> fines = fineService.generateFines();
        log.info("Fines generated successfully.");
        return new ResponseEntity<>(fines,HttpStatus.CREATED);
    }

    @PutMapping("/clearfine")
    public ResponseEntity<String> returned(@RequestParam int memberID,@RequestParam double amount){
        log.info("Clearing fine for memberID: {} with amount: {}", memberID, amount);
        try {
            String response = fineService.returnBook(memberID, amount);
            log.info("Fine cleared successfully for memberID: {}", memberID);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e){
            log.error("Error clearing fine for memberID {}: {}", memberID, e.getMessage());
            return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping
    public ResponseEntity<List<Fine>> getAllFines(){
        System.out.println("coming for all fines");
        log.info("Fetching all fines...");
        List<Fine> fines = fineService.getAllFines();
        log.info("Fetched {} fines.", fines.size());
        return new ResponseEntity<>(fines,HttpStatus.CREATED);
    }



    @GetMapping("/member/{memberID}")
    public ResponseEntity<List<Fine>> getFinesByMemberID(@PathVariable int memberID) {
        log.info("Fetching fines for memberID: {}", memberID);
        try {
            List<Fine> fines = fineService.getFinesByMemberID(memberID);
            log.info("Fetched {} fines for memberID: {}", fines.size(), memberID);
            return new ResponseEntity<>(fines, HttpStatus.CREATED);
        } catch (Exception e){
            log.error("Error fetching fines for memberID {}: {}", memberID, e.getMessage());
            return new ResponseEntity(e.getMessage(),HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/totalfine/member/{memberID}")
    public ResponseEntity<String> getTotalFine(@PathVariable int memberID) {
        log.info("Fetching total fine for memberID: {}", memberID);
        double totalFine = fineService.getFinesByMember(memberID);
        log.info("Total fine for memberID {} is {}", memberID, totalFine);
        return new ResponseEntity<>("The total amount to be paid is " + totalFine, HttpStatus.CREATED);
    }

    @GetMapping("getDays")
    public int getDays(){
        return fineService.getDays();
    }

    @GetMapping("/transaction/{id}")
    public ResponseEntity<Fine> getBorrowingTransaction(@PathVariable("id")int id){
        return new ResponseEntity<>(fineService.getBorrowingTransaction(id),HttpStatus.CREATED);
    }

    @DeleteMapping("/member/{id}")
    public ResponseEntity<List<Fine>> deleteTransactionByMemberId(@PathVariable("id")int id){
        try{
            List<Fine> list = fineService.deleteBookByMemberId(id);
            return new ResponseEntity<>(list,HttpStatus.CREATED);
        }catch (Exception e){
            return new ResponseEntity(e.getMessage(),HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/book/{id}")
    public ResponseEntity<List<Fine>> deleteTransactionByBookId(@PathVariable("id")int id){
        try{
            notificationInterface.deleteAllNotifications();
            List<Fine> list = fineService.deleteBookByBookId(id);
            return new ResponseEntity<>(list,HttpStatus.CREATED);
        }catch (Exception e){
            return new ResponseEntity(e.getMessage(),HttpStatus.NOT_FOUND);
        }
    }
}
