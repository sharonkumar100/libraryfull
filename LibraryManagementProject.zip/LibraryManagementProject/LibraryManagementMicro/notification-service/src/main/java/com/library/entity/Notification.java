package com.library.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;

@Entity
@Table(name = "Notification")
@Data
public class Notification {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int notificationID;
//    @ManyToOne
//    @JoinColumn(name = "MemberID", nullable = false)
//    private Member member;
    private String email;
    private int memberId;
    private String message;
    private LocalDate dateSent;
}