package com.library.controller;

import com.library.entity.Notification;
import com.library.exception.NotificationException;
import com.library.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/notifications")
@CrossOrigin(origins = "http://localhost:4200")
public class NotificationController {
    @Autowired
    private NotificationService notificationService;

    @PostMapping("/send")
    public ResponseEntity<String> sendNotification(@RequestParam int memberID) {
        String notification = notificationService.sendNotification(memberID);
        return new ResponseEntity<>(notification, HttpStatus.CREATED);
    }

    @PostMapping("/generate")
    public ResponseEntity<Notification> generate() {
        List<Notification> notification = notificationService.generate();
        return new ResponseEntity(notification, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<Notification>> getAllNotifications(){
        try {
            List<Notification> notifications = notificationService.getAllNotifications();
            return new ResponseEntity<>(notifications, HttpStatus.CREATED);
        }catch(NotificationException nt) {
            return new ResponseEntity(nt.getMessage(),HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/id/{memberID}")
    public ResponseEntity<List<Notification>> getNotificationsByMemberID(@PathVariable int memberID) {
        try {
            List<Notification> notifications = notificationService.getNotificationsByMemberID(memberID);
            return new ResponseEntity<>(notifications, HttpStatus.CREATED);
        }catch (NotificationException nt){
            return new ResponseEntity(nt.getMessage(), HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/email/{memberID}")
    public ResponseEntity<List<Notification>> getNotificationsByEmail(@PathVariable String email) {
        try {
            List<Notification> notifications = notificationService.getNotificationsByEmail(email);
            return new ResponseEntity<>(notifications, HttpStatus.CREATED);
        }
        catch (NotificationException nt){
            return new ResponseEntity(nt.getMessage(), HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping
    public ResponseEntity<List<Notification>> deleteAllNotifications(){
        try{
            List<Notification> list = notificationService.deleteAllNotifications();
            return new ResponseEntity<>(list,HttpStatus.CREATED);
        }catch (Exception e){
            return new ResponseEntity(e.getMessage(),HttpStatus.NOT_FOUND);
        }
    }
}