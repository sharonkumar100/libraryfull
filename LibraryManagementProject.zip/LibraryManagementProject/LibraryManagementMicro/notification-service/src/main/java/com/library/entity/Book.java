package com.library.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

//@Entity
//@Table(name = "Book")
@Data
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "book_id")
    private int bookID;

    @NotNull
    @Size(max = 100)
    @Column(name = "book_title", nullable = false, length = 100)
    private String title;

    @NotNull
    @Size(max = 50)
    @Column(name = "book_author", nullable = false, length = 50)
    private String author;

    @Size(max = 30)
    @Column(name = "book_genre", length = 30)
    private String genre;

    @NotNull
    @Size(max = 13)
    @Column(name = "book_isbn", nullable = false, length = 13, unique = true)
    private String isbn;

    @Column(name = "year_published")
    private int yearPublished;

    @Column(name = "available_copies")
    private int availableCopies;

    private String bookurl;
}