//package com.library.service;

package com.library.service;

import com.library.entity.*;
import com.library.exception.NotificationException;
import com.library.feign.BookInterface;
import com.library.feign.BorrowingTransactionInterface;
import com.library.feign.FineInterface;
import com.library.feign.MemberInterface;
import com.library.repository.NotificationRepository;
import com.netflix.discovery.converters.Auto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service

public class NotificationService {

    private static final long before_inform_days = 5;

    @Autowired
    private JavaMailSender mailSender;

    @Autowired

    private NotificationRepository notificationRepository;

    @Autowired
    private MemberInterface memberInterface;

    @Autowired
    BorrowingTransactionInterface borrowingTransactionInterface;

    @Autowired
    FineInterface fineInterface;

    @Autowired
    BookInterface bookInterface;



    public String sendNotification(int id) {

     List<Notification> ls = null;
//     if(memberRepository.findById(id).isEmpty()){
        ResponseEntity<Member> member = memberInterface.getMember(id);
     if(member == null){
         return "No member present with that id";
     }
     else{

        ls = notificationRepository.findByMemberId(id);
         if(ls == null){
             return "No Dues for the member";
         }
         else{
             return "This member has due books";
         }

     }
    }

    public String sendNotificationToPerson(String sendTo,String text,String subject) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom("librarymanagement29@gmail.com");
        message.setTo(sendTo);
        message.setText(text);
        message.setSubject(subject);
        mailSender.send(message);
        return "mail sent successfully";

    }

    public List<Notification> getNotificationsByMemberID(int memberID) {
        return notificationRepository.findByMemberId(memberID);

    }

    public List<Notification> generate() {

//        List<BorrowingTransaction> btlist = borrowingTransactionRepository.findAll();
        ResponseEntity<List<BorrowingTransaction>> btlist = borrowingTransactionInterface.getAllTransactions();
        if(btlist == null){
            throw new NotificationException("no transaction to send because the borrowing transactions list is empty");
        }

        LocalDate currentDate = LocalDate.now();

        List<Notification> notificationList = new ArrayList<>();

        for(BorrowingTransaction bt :btlist.getBody()){

            Notification nt =null;

            LocalDate borrowDate = bt.getBorrowDate();


            long daysOverdue = ChronoUnit.DAYS.between(borrowDate, currentDate);

            if(daysOverdue>= fineInterface.getDays()){

//                Fine fine = fineRepository.findByBorrowingTransaction(bt);
                Fine fine = fineInterface.getBorrowingTransaction(bt.getTransactionID()).getBody();

//                long beforedays =ChronoUnit.DAYS.between(borrowDate.plusDays(FineService.days), currentDate);
                long beforedays =ChronoUnit.DAYS.between(borrowDate.plusDays(fineInterface.getDays()), currentDate);
                if(fine!=null && fine.getStatus().equals("Pending")){
                    nt = new Notification();
                    nt.setMemberId(bt.getMemberId());
//                    nt.setMember(bt.getMember());

                    Book book = bookInterface.getBook(bt.getBookId()).getBody();
                    nt.setMessage("Your due date was completed on "+borrowDate.plusDays(fineInterface.getDays())+" and the amount to be paid is "+fine.getAmount()+" for the book "+book.getTitle());

                    nt.setDateSent(LocalDate.now());
                    String subject = "Your Borrowed Book is Overdue";

//                    sendNotificationToPerson(nt.getMember().getEmail(),nt.getMessage(),subject);
                    Member member = memberInterface.getMember(nt.getMemberId()).getBody();
                    nt.setEmail(member.getEmail());
                    sendNotificationToPerson(member.getEmail(),nt.getMessage(),subject);

                }else if(fine!=null && bt.getStatus().equals("Borrowed") && beforedays<before_inform_days){
                    nt = new Notification();
//                    nt.setMember(bt.getMember());
                    nt.setMemberId(bt.getMemberId());
                    Book book = bookInterface.getBook(bt.getBookId()).getBody();
                    nt.setMessage("Your due date was near you have to return the book"+book+ " on "+borrowDate.plusDays(fineInterface.getDays()));

                    nt.setDateSent(LocalDate.now());
                    String subject = "Book Return Due Soon";

                    Member member = memberInterface.getMember(nt.getMemberId()).getBody();
                    nt.setEmail(member.getEmail());
                    sendNotificationToPerson(member.getEmail(),nt.getMessage(),subject);

                }

            }
            if(nt!=null){
                notificationList.add(nt);
            }


        }

        notificationRepository.deleteAll();

        notificationRepository.saveAll(notificationList);

        return notificationList;

    }

    public List<Notification> getAllNotifications() {

        List<Notification> list = generate();;
        if(list.isEmpty()){
            throw new NotificationException("No notifications to show");
        }else{
            return list;
        }
    }

    public List<Notification> getNotificationsByEmail(String email) {
        Optional<List<Notification>> list =  notificationRepository.findByEmail(email);
        if(list.isEmpty()){
            throw new NotificationException("Notifications are Empty");
        }
        else{
            return list.get();
        }
    }

    public List<Notification> deleteAllNotifications() {
        List<Notification> list = notificationRepository.findAll();
        if(list.isEmpty()){
            throw new NotificationException("No notifications to show");
        }
        return list;
    }
}































