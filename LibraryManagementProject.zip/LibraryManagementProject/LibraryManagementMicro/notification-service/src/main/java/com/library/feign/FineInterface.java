package com.library.feign;

import com.library.entity.Fine;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient("FINE-SERVICE")
public interface FineInterface {
    @PostMapping("/fines/generate")
    public ResponseEntity<List<Fine>> generateFines();

    @GetMapping
    public ResponseEntity<List<Fine>> getAllFines();

    @PutMapping("/fines/clearfine")
    public ResponseEntity<String> returned(@RequestParam int memberID, @RequestParam double amount);

    @GetMapping("/fines/member/{memberID}")
    public ResponseEntity<List<Fine>> getFinesByMemberID(@PathVariable int memberID);

    @GetMapping("/fines/totalfine/member/{memberID}")
    public ResponseEntity<String> getTotalFine(@PathVariable int memberID) ;

    @GetMapping("/fines/getDays")
    public int getDays();

    @GetMapping("/fines/transaction/{id}")
    public ResponseEntity<Fine> getBorrowingTransaction(@PathVariable("id")int id);
}
