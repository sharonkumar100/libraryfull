package com.library.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;


//@Entity
//@Table(name = "Fine")
@Data
public class Fine {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int fineID;
 
    
//    @ManyToOne
//    @JoinColumn(name = "MemberID", nullable = false)
//    private Member member;

    private int memberId;
 
//    @OneToOne
//    @JoinColumn(name = "TransactionID",nullable = false)
//    private BorrowingTransaction borrowingTransaction;

    private int transactionId;
    
    private double amount;
    private String status; // Paid or Pending
    private LocalDate transactionDate;
}