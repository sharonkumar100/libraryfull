package com.library.feign;

import com.library.entity.Member;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

//@FeignClient(url="http://localhost:6062/",value="MEMBER-SERVICE")
@FeignClient(value="MEMBER-SERVICE")

public interface MemberInterface {
    @PostMapping("/members/register")
    public ResponseEntity<String> registerMember(@RequestBody Member member);

    @GetMapping("/members/email/{email}")
    public ResponseEntity<Member> getMemberByEmail(@PathVariable String email);

    @GetMapping("/members")
    public ResponseEntity<List<Member>> getAllMembers() ;

    @GetMapping("/members/id/{id}")
    public ResponseEntity<Member> getMember(@PathVariable("id") int id);
//
    @DeleteMapping("/members/{id}")
    public ResponseEntity<Member> deleteMember(@PathVariable("id") int id) ;

    @PutMapping("/members/{id}")
    public ResponseEntity<Member> updateMember(@PathVariable("id") int id, @RequestBody Member member) ;
}
