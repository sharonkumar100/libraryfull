package com.library.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;

@Entity
@Table(name = "BorrowingTransaction")
@Data
public class BorrowingTransaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int transactionID;

//    @ManyToOne
//    @JoinColumn(name = "BookID", nullable = false)
//    private Book book;
    private int bookId;
    private int memberId;

//    @ManyToOne
//    @JoinColumn(name = "MemberID", nullable = false)
//    private Member member;

    private LocalDate borrowDate;
    private LocalDate returnDate;
    private String status; // Borrowed or Returned
}
