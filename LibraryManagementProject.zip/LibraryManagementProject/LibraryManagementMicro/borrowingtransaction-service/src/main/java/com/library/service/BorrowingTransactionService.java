//package com.library.service;
//
//import java.time.LocalDate;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.library.exception.BorrowingTransactionException;
//import com.library.entity.Book;
//import com.library.entity.BorrowingTransaction;
//import com.library.entity.Member;
//import com.library.repository.BookRepository;
//import com.library.repository.BorrowingTransactionRepository;
//import com.library.repository.MemberRepository;
//
//@Slf4j
//@Service
//public class BorrowingTransactionService {
//    @Autowired
//    private BorrowingTransactionRepository borrowingTransactionRepository;
//    @Autowired
//    private BookRepository bookRepository;
//    @Autowired
//    private MemberRepository memberRepository;
//
//    public List<BorrowingTransaction> borrowBooks(List<Integer> bookIDs, int memberID) {
//        // Check if member exists first
//        Member member = memberRepository.findById(memberID)
//                .orElseThrow(() -> new BorrowingTransactionException("Member not found"));
//
//        List<BorrowingTransaction> transactions = new ArrayList<>();
//
//        for (int bookID : bookIDs) {
//            // Check if the book exists
//            Book book = bookRepository.findById(bookID)
//                    .orElseThrow(() -> new BorrowingTransactionException("Book not found"));
//
//            // Check if the book has available copies
//            if (book.getAvailableCopies() <= 0) {
//                throw new BorrowingTransactionException("No available copies for book: " + book.getBookID());
//            }
//
//            // Check if the member already borrowed the book
//            List<BorrowingTransaction> borrowingTransactionHistory = borrowingTransactionRepository.findByMember_MemberID(memberID);
//            for (BorrowingTransaction b : borrowingTransactionHistory) {
//                if (b.getBook().getBookID() == bookID) {
//                    throw new BorrowingTransactionException("Member has already borrowed this book: " + book.getBookID());
//                }
//            }
//
//            // Create the borrowing transaction
//            BorrowingTransaction transaction = new BorrowingTransaction();
//            transaction.setBook(book);
//            transaction.setMember(member);
//            transaction.setBorrowDate(LocalDate.now());
//            transaction.setStatus("Borrowed");
//
//            // Update available copies
//            book.setAvailableCopies(book.getAvailableCopies() - 1);
//            bookRepository.save(book);
//
//            // Save the borrowing transaction
//            transactions.add(borrowingTransactionRepository.save(transaction));
//        }
//
//        return transactions;
//    }
//
//    public List<BorrowingTransaction> returnBooks(List<Integer> bookIDs, int memberID) {
//        log.info(bookIDs + "  bookId member id " + memberID);
//
//        Member member = memberRepository.findById(memberID)
//                .orElseThrow(() -> new BorrowingTransactionException("Member not found"));
//
//        List<BorrowingTransaction> transactions = new ArrayList<>();
//
//        for (int bookID : bookIDs) {
//            List<BorrowingTransaction> transactionList = borrowingTransactionRepository
//                    .findByBook_BookIDAndMember_MemberID(bookID, memberID);
//
//            if (transactionList.isEmpty()) {
//                throw new BorrowingTransactionException("No borrowing transaction found for book: " + bookID);
//            }
//
//            BorrowingTransaction transaction = transactionList.get(0); // Assuming only one transaction for each book-member combination
//
//            if (transaction.getStatus().equals("Returned")) {
//                throw new BorrowingTransactionException("Book already returned: " + bookID);
//            }
//
//            transaction.setReturnDate(LocalDate.now());
//            transaction.setStatus("Returned");
//
//            // Update available copies of the book
//            Book book = transaction.getBook();
//            book.setAvailableCopies(book.getAvailableCopies() + 1);
//            bookRepository.save(book);
//
//            transactions.add(borrowingTransactionRepository.save(transaction));
//        }
//
//        return transactions;
//    }
//
//    public List<BorrowingTransaction> getTransactionsByMember(int memberID) {
//        Member member = memberRepository.findById(memberID)
//                .orElseThrow(() -> new BorrowingTransactionException("Member not found"));
//        return borrowingTransactionRepository.findByMember(member);
//    }
//
//    public List<BorrowingTransaction> getTransactionsByBook(int bookID) {
//        Book book = bookRepository.findById(bookID)
//                .orElseThrow(() -> new BorrowingTransactionException("Book not found"));
//        return borrowingTransactionRepository.findByBook(book);
//    }
//
//    public List<BorrowingTransaction> getAllTransactions() {
//        return borrowingTransactionRepository.findAll();
//    }
//}

package com.library.service;

import com.library.entity.Book;
import com.library.entity.BorrowingTransaction;
import com.library.entity.Member;
import com.library.exception.BorrowingTransactionException;
import com.library.feign.BookInterface;
import com.library.feign.MemberInterface;
import com.library.repository.BorrowingTransactionRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
public class BorrowingTransactionService {

    @Autowired
    private BorrowingTransactionRepository borrowingTransactionRepository;

    @Autowired
    MemberInterface memberInterface;

    @Autowired
    BookInterface bookInterface;


    public List<BorrowingTransaction> borrowBooks(List<Integer> bookIDs, int memberID) {

        ResponseEntity<Member> member = memberInterface.getMember(memberID);
        System.out.println("after coming here for member"+member);
        if(member==null){
            System.out.println("Member is null");
            throw new BorrowingTransactionException("Member not found");
        }
        List<BorrowingTransaction> transactions = new ArrayList<>();

        for (int bookID : bookIDs) {
            System.out.println("coming here for member for loop");
            Book book = bookInterface.getBook(bookID).getBody();
            System.out.println("coming here for member after book interface");
            if (book.getAvailableCopies() <= 0) {
                System.out.println("Inside Borrowing Transaction Exception");
                throw new BorrowingTransactionException("No available copies for book: " + book.getBookID());
            }
            System.out.println("beforre list");
            List<BorrowingTransaction> borrowingTransactionHistory = borrowingTransactionRepository.findByMemberId(memberID).get();
            for (BorrowingTransaction b : borrowingTransactionHistory) {
                if (b.getBookId() == bookID) {
                    System.out.println("coming to exception");
                    throw new BorrowingTransactionException("Member has already borrowed this book: " + book.getBookID());
                }
            }
            System.out.println("after list");
            System.out.println("coming here after for loop");
            BorrowingTransaction transaction = new BorrowingTransaction();
            transaction.setBookId(bookID);
            transaction.setMemberId(memberID);
            transaction.setBorrowDate(LocalDate.now());
            transaction.setStatus("Borrowed");
            book.setAvailableCopies(book.getAvailableCopies() - 1);
            System.out.println("before update Book");
            bookInterface.updateBook(bookID,book);
            System.out.println("after update Book");
            System.out.println("Book for loop after update");
            transactions.add(borrowingTransactionRepository.save(transaction));
        }

        return transactions;
    }

    public List<BorrowingTransaction> returnBooks(List<Integer> bookIDs, int memberID) {
        log.info(bookIDs + "  bookId member id " + memberID);
        ResponseEntity<Member> member = memberInterface.getMember(memberID);
        if(member==null){
            throw new  BorrowingTransactionException("No member found");
        }
        List<BorrowingTransaction> transactions = new ArrayList<>();

        for (int bookID : bookIDs) {

            if(borrowingTransactionRepository.findByBookIdAndMemberId(bookID,memberID).isEmpty()){
                throw new BorrowingTransactionException("No borrowing transaction found for book: "+bookID);
            }
            List<BorrowingTransaction> transactionList = borrowingTransactionRepository.findByBookIdAndMemberId(bookID,memberID).get();


            BorrowingTransaction transaction = transactionList.get(0); // Assuming only one transaction per book-member pair

            if (transaction.getStatus().equals("Returned")) {
                throw new BorrowingTransactionException("Book already returned: " + bookID);
            }

            transaction.setReturnDate(LocalDate.now());
            transaction.setStatus("Returned");
            Book book = bookInterface.getBook(bookID).getBody();
            book.setAvailableCopies(book.getAvailableCopies() + 1);
            bookInterface.updateBook(bookID,book);
            transactions.add(borrowingTransactionRepository.save(transaction));
        }

        return transactions;
    }


    public List<BorrowingTransaction> getTransactionsByMember(int memberID) {
        ResponseEntity<Member> member = memberInterface.getMember(memberID);
        if(member==null){
            throw new BorrowingTransactionException("no member found with the transaction");
        }
        return borrowingTransactionRepository.findByMemberId(memberID).get();
    }

    public List<BorrowingTransaction> getTransactionsByBook(int bookID) {

        ResponseEntity<Book> book = bookInterface.getBook(bookID);
        if(book == null){
            throw new BorrowingTransactionException("Book not found");
        }
        return borrowingTransactionRepository.findByBookId(bookID);

    }

    public List<BorrowingTransaction> getAllTransactions() {
        return borrowingTransactionRepository.findAll();
    }


    public List<BorrowingTransaction> getTransactionsByMemberAndBook(int memberID, int bookID) {
        Optional<List<BorrowingTransaction>> transac =  borrowingTransactionRepository.findByBookIdAndMemberId(bookID,memberID);
        if(transac.isEmpty()){
            throw new BorrowingTransactionException("No Transactions");
        }else{
            return transac.get();
        }
    }

    public List<BorrowingTransaction> deleteBookByMemberId(int id) {
        List<BorrowingTransaction> list = borrowingTransactionRepository.deleteByMemberId(id);
        if(list.isEmpty()){
            throw new BorrowingTransactionException("No Borrowing Transactions with that memberId");
        }else{
            return list;
        }

    }

    public List<BorrowingTransaction> deleteBookByBookId(int id) {
        List<BorrowingTransaction> list = borrowingTransactionRepository.findByBookId(id);
        borrowingTransactionRepository.deleteByBookId(id);
        if(list.isEmpty()){
            throw new BorrowingTransactionException("No Borrowing Transactions with that BookId");
        }else{
            return list;
        }
    }
}
