package com.library.controller;

import com.library.entity.Book;
import com.library.entity.BorrowingTransaction;
import com.library.entity.Member;
import com.library.exception.BorrowingTransactionException;
import com.library.service.BorrowingTransactionService;
import jakarta.ws.rs.Path;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.lang.reflect.Executable;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/transactions")
@CrossOrigin("http://localhost:4200")
public class BorrowingTransactionController {
    @Autowired
    private BorrowingTransactionService borrowingTransactionService;

    @PostMapping("/borrow")
    public ResponseEntity<List<BorrowingTransaction>> borrowBooks(@RequestParam List<Integer> bookIDs, @RequestParam int memberID) {
        System.out.println("It is coming to borrowbok method"+bookIDs+"  "+memberID);
        try {
            List<BorrowingTransaction> transactions = borrowingTransactionService.borrowBooks(bookIDs, memberID);
            return new ResponseEntity<>(transactions, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity(e.getMessage(),HttpStatus.NOT_FOUND); // Added meaningful message in case of failure
        }
    }
//
    @PostMapping("/return")
    public ResponseEntity<List<BorrowingTransaction>> returnBooks(@RequestParam List<Integer> bookIDs, @RequestParam int memberID) {
        try {
            List<BorrowingTransaction> transactions = borrowingTransactionService.returnBooks(bookIDs, memberID);
            return new ResponseEntity<>(transactions, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity(e.getMessage(),HttpStatus.NOT_FOUND); // Added meaningful message in case of failure
        }
    }

    @GetMapping("/memberAndBook/{memberID}/{bookID}")
    public ResponseEntity<List<BorrowingTransaction>> getMemberAndBook(@PathVariable("memberID") int memberID, @PathVariable("bookID") int bookID){
        try {
            List<BorrowingTransaction> transactions = borrowingTransactionService.getTransactionsByMemberAndBook(memberID, bookID);
            return new ResponseEntity<>(transactions, HttpStatus.OK);
        }catch (Exception e){
            return new ResponseEntity(e.getMessage(),HttpStatus.NOT_FOUND);
        }
    }
//
    @GetMapping("/member/{memberID}")
    public ResponseEntity<List<BorrowingTransaction>> getTransactionsByMember(@PathVariable("memberID") int memberID) {
        List<BorrowingTransaction> transactions = borrowingTransactionService.getTransactionsByMember(memberID);
        return new ResponseEntity<>(transactions, HttpStatus.OK);
    }
//
    @GetMapping
    public ResponseEntity<List<BorrowingTransaction>> getAllTransactions() {
        List<BorrowingTransaction> transactions = borrowingTransactionService.getAllTransactions();
        if (transactions.isEmpty()) {
            return new ResponseEntity<>(transactions,HttpStatus.CREATED); // No transactions found, return 204
        } else {
            return new ResponseEntity<>(transactions, HttpStatus.OK);
        }
    }

    @GetMapping("/book/{bookID}")
    public ResponseEntity<List<BorrowingTransaction>> getTransactionsByBook(@PathVariable("bookID") int bookID) {
        System.out.println("it is working");
        try{
        List<BorrowingTransaction> transactions = borrowingTransactionService.getTransactionsByBook(bookID);
            return new ResponseEntity<>(transactions,HttpStatus.CREATED);
        }catch(Exception e){
        return new ResponseEntity(e.getMessage(), HttpStatus.OK);
        }
    }

    @DeleteMapping("/member/{id}")
    public ResponseEntity<List<BorrowingTransaction>> deleteBookByMemberId(@PathVariable("id")int id){
        try{
            List<BorrowingTransaction> list = borrowingTransactionService.deleteBookByMemberId(id);
            return new ResponseEntity<>(list,HttpStatus.CREATED);
        }catch (Exception e){
            return new ResponseEntity(e.getMessage(),HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/book/{id}")
    public ResponseEntity<List<BorrowingTransaction>> deleteBookByBookId(@PathVariable("id")int id){
        try{
            System.out.println("comint to delteBookById");
            List<BorrowingTransaction> list = borrowingTransactionService.deleteBookByBookId(id);
            System.out.println("coming here after this");
            return new ResponseEntity<>(list,HttpStatus.CREATED);
        }catch (Exception e){
            System.out.println("this is coming to error"+e.getMessage());
            return new ResponseEntity(e.getMessage(),HttpStatus.NOT_FOUND);
        }
    }
}
