package com.library.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

//@Entity
//@Table(name = "Member")
@Data
public class Member {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int memberID;

    @NotNull(message = "Name cannot be null")
    @Size(min = 1, message = "Name must have at least 1 character")
    private String name;

    @NotNull(message = "Email cannot be null")
    @Email(message = "Email should be valid")
    @Size(max = 320, message = "Email should not be longer than 320 characters")
    @Pattern(regexp = "^[^\\s]+@[\\w-]+(\\.[\\w-]+)+$", message = "Email should not contain spaces and should have a valid format")
    @Column(unique = true)
    private String email;

    @NotNull(message = "Phone number cannot be null")
    @Pattern(regexp = "^[0-9]{10}$", message = "Phone number must be 10 digits long and contain only numbers")
    private String phone;

    private String address;

    @NotNull(message = "password cannot be null")
    private String password;

//    @NotNull(message = "Confirm Password cannot be null")
//    private String confirmPassword;

    private String membershipStatus; // Active or Inactive

//    @Lob
//    @Column(name = "profile_image", columnDefinition = "LONGBLOB")
//    private byte[] profileImage;   // 👈 storing image as binary data

    private String profile_image;
}
