package com.library.repository;

import com.library.entity.Book;
import com.library.entity.BorrowingTransaction;
import com.library.entity.Member;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BorrowingTransactionRepository extends JpaRepository<BorrowingTransaction, Integer> {
//    List<BorrowingTransaction> findByMember_MemberID(int memberID);
//    List<BorrowingTransaction> findByBook_BookID(int bookID);
    Optional<List<BorrowingTransaction>> findByMemberId(int memberId);
    List<BorrowingTransaction> findByBookId(int bookId);
    Optional<List<BorrowingTransaction>> findByBookIdAndMemberId(int bookId,int memberId);

    List<BorrowingTransaction> deleteByMemberId(int memberId);

    List<BorrowingTransaction> deleteByBookId(int bookId);
//    List<BorrowingTransaction> findByBook(Book book);

//    List<BorrowingTransaction> findByBook_BookIDAndMember_MemberID(int bookID, int memberID);
}
