package com.library.exception;

public class BorrowingTransactionException extends RuntimeException {
    public BorrowingTransactionException(String message) {
        super(message);
    }
}
