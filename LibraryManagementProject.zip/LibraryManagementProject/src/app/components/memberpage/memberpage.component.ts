import { Component } from '@angular/core';

@Component({
  selector: 'app-memberpage',
  imports: [],
  templateUrl: './memberpage.component.html',
  styleUrl: './memberpage.component.css'
})
export class MemberpageComponent {

}
