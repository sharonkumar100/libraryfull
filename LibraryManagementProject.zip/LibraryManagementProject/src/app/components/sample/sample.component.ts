import { Component } from '@angular/core';
import { MainpageComponent } from "../mainpage/mainpage.component";

@Component({
  selector: 'app-sample',
  imports: [MainpageComponent],
  templateUrl: './sample.component.html',
  styleUrl: './sample.component.css'
})
export class SampleComponent {

}
