export class Notification{
    notificationID:number=0;
    memberId:number=0;
    message:string='';
    dateSent:string='';
}