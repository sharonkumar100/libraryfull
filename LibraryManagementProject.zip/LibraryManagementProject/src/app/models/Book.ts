export class Book {
  bookID: number=0;
  title: string='';
  author: string='';
  genre: string='';
  isbn: string='';
  yearPublished: number=0;
  availableCopies : number=0;
  bookurl?:string='';

}
