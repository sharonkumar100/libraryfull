export class Fine {
    fineID: number=0;
    memberId: number=0;
    bookId:number=0;
    transactionId: number=0;
    amount: number=0;
    status: string=''; // Paid or Pending
    transactionDate: string=''; 
}