export class BorrowingTransaction{
    transactionID:number=0;
    bookId:number=0;
    memberId:number=0;
    borrowDate:string='';
    returnDate:string='';
    status:string='';

}