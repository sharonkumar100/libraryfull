export class Member {
    memberID: number = 0;
    name: string = '';
    email: string = '';
    phone: string = '';
    address: string = '';
    password: string = '';
    membershipStatus: string = '';
    role:string='';
    profileimg?: string;
  }
  

  
  export class MemberData{
    memberID: number = 0;
    email: string = '';
    role:string='';
  }